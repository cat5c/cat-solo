--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE "CC";
ALTER ROLE "CC" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE "postgres";
ALTER ROLE "postgres" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;






--
-- Database creation
--

CREATE DATABASE "CC" WITH TEMPLATE = template0 OWNER = "CC";
CREATE DATABASE "contacts" WITH TEMPLATE = template0 OWNER = "CC";
CREATE DATABASE "photogur-dev" WITH TEMPLATE = template0 OWNER = "CC";
CREATE DATABASE "photogur-test" WITH TEMPLATE = template0 OWNER = "CC";
REVOKE ALL ON DATABASE "template1" FROM PUBLIC;
REVOKE ALL ON DATABASE "template1" FROM "postgres";
GRANT ALL ON DATABASE "template1" TO "postgres";
GRANT CONNECT ON DATABASE "template1" TO PUBLIC;
CREATE DATABASE "wyncode-todo-dev" WITH TEMPLATE = template0 OWNER = "CC";
CREATE DATABASE "wyncode-todo-test" WITH TEMPLATE = template0 OWNER = "CC";


\connect "CC"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect "contacts"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: people; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "people" (
    "id" integer NOT NULL,
    "first_name" character(50) NOT NULL,
    "last_name" character(50) NOT NULL,
    "phone" character(50),
    "email" character(50),
    "company" integer,
    "title" character(50)
);


ALTER TABLE "people" OWNER TO "CC";

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "people_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "people_id_seq" OWNER TO "CC";

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "people_id_seq" OWNED BY "people"."id";


--
-- Name: people id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "people" ALTER COLUMN "id" SET DEFAULT "nextval"('"people_id_seq"'::"regclass");


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "people" ("id", "first_name", "last_name", "phone", "email", "company", "title") FROM stdin;
1	Auston                                            	Bunsen                                            	954-670-3289                                      	auston@wc.co                                      	\N	Prof                                              
\.


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"people_id_seq"', 3, true);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "people"
    ADD CONSTRAINT "people_pkey" PRIMARY KEY ("id");


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect -reuse-previous=on "dbname='photogur-dev'"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "ar_internal_metadata" (
    "key" character varying NOT NULL,
    "value" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "ar_internal_metadata" OWNER TO "CC";

--
-- Name: cities; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "cities" (
    "id" bigint NOT NULL,
    "name" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "latitude" double precision,
    "longitude" double precision
);


ALTER TABLE "cities" OWNER TO "CC";

--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "cities_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "cities_id_seq" OWNER TO "CC";

--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "cities_id_seq" OWNED BY "cities"."id";


--
-- Name: comments; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "comments" (
    "id" bigint NOT NULL,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "picture_id" bigint,
    "body" "text",
    "user_id" bigint
);


ALTER TABLE "comments" OWNER TO "CC";

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "comments_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "comments_id_seq" OWNER TO "CC";

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "comments_id_seq" OWNED BY "comments"."id";


--
-- Name: pictures; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "pictures" (
    "id" bigint NOT NULL,
    "title" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "user_id" integer,
    "image_file_name" character varying,
    "image_content_type" character varying,
    "image_file_size" integer,
    "image_updated_at" timestamp without time zone,
    "cached_votes_total" integer DEFAULT 0,
    "cached_votes_score" integer DEFAULT 0,
    "cached_votes_up" integer DEFAULT 0,
    "cached_votes_down" integer DEFAULT 0,
    "cached_weighted_score" integer DEFAULT 0,
    "cached_weighted_total" integer DEFAULT 0,
    "cached_weighted_average" double precision DEFAULT 0.0,
    "latitude" double precision,
    "longitude" double precision,
    "city_id" bigint
);


ALTER TABLE "pictures" OWNER TO "CC";

--
-- Name: pictures_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "pictures_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "pictures_id_seq" OWNER TO "CC";

--
-- Name: pictures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "pictures_id_seq" OWNED BY "pictures"."id";


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "schema_migrations" (
    "version" character varying NOT NULL
);


ALTER TABLE "schema_migrations" OWNER TO "CC";

--
-- Name: users; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "users" (
    "id" bigint NOT NULL,
    "username" character varying,
    "email" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "password_digest" character varying,
    "name" character varying
);


ALTER TABLE "users" OWNER TO "CC";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "users_id_seq" OWNER TO "CC";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "users_id_seq" OWNED BY "users"."id";


--
-- Name: votes; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "votes" (
    "id" bigint NOT NULL,
    "votable_type" character varying,
    "votable_id" integer,
    "voter_type" character varying,
    "voter_id" integer,
    "vote_flag" boolean,
    "vote_scope" character varying,
    "vote_weight" integer,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "votes" OWNER TO "CC";

--
-- Name: votes_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "votes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "votes_id_seq" OWNER TO "CC";

--
-- Name: votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "votes_id_seq" OWNED BY "votes"."id";


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "cities" ALTER COLUMN "id" SET DEFAULT "nextval"('"cities_id_seq"'::"regclass");


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments" ALTER COLUMN "id" SET DEFAULT "nextval"('"comments_id_seq"'::"regclass");


--
-- Name: pictures id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "pictures" ALTER COLUMN "id" SET DEFAULT "nextval"('"pictures_id_seq"'::"regclass");


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "users" ALTER COLUMN "id" SET DEFAULT "nextval"('"users_id_seq"'::"regclass");


--
-- Name: votes id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "votes" ALTER COLUMN "id" SET DEFAULT "nextval"('"votes_id_seq"'::"regclass");


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "ar_internal_metadata" ("key", "value", "created_at", "updated_at") FROM stdin;
environment	development	2017-08-06 17:58:30.845596	2017-08-06 17:58:30.845596
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "cities" ("id", "name", "created_at", "updated_at", "latitude", "longitude") FROM stdin;
1	New York City	2017-08-08 22:12:57.700216	2017-08-08 22:12:57.700216	40.7127837000000028	-74.0059413000000035
2	Los Angeles	2017-08-08 22:12:58.381344	2017-08-08 22:12:58.381344	34.0522342000000009	-118.243684900000005
3	Chicago	2017-08-08 22:12:59.141518	2017-08-08 22:12:59.141518	41.8781135999999989	-87.6297981999999962
4	Houston	2017-08-08 22:12:59.778802	2017-08-08 22:12:59.778802	29.7604267	-95.3698028000000022
5	Philadelphia	2017-08-08 22:13:00.456241	2017-08-08 22:13:00.456241	39.9525839000000005	-75.1652215000000012
6	Phoenix	2017-08-08 22:13:01.304119	2017-08-08 22:13:01.304119	33.4483771000000019	-112.074037300000001
7	San Antonio	2017-08-08 22:13:01.941945	2017-08-08 22:13:01.941945	29.4241218999999994	-98.4936281999999892
8	San Diego	2017-08-08 22:13:02.80891	2017-08-08 22:13:02.80891	32.7157380000000018	-117.1610838
9	Dallas	2017-08-08 22:13:03.467072	2017-08-08 22:13:03.467072	32.776664199999999	-96.7969878999999906
10	San Jose	2017-08-08 22:13:04.053145	2017-08-08 22:13:04.053145	37.3382081999999969	-121.886328599999999
11	Austin	2017-08-08 22:13:04.907109	2017-08-08 22:13:04.907109	30.2671530000000004	-97.743060799999995
12	Jacksonville	2017-08-08 22:13:05.483267	2017-08-08 22:13:05.483267	30.3321837999999993	-81.6556509999999918
13	Indianapolis	2017-08-08 22:13:06.348592	2017-08-08 22:13:06.348592	39.7684029999999993	-86.1580680000000001
14	San Francisco	2017-08-08 22:13:07.005015	2017-08-08 22:13:07.005015	37.7749294999999989	-122.419415499999999
15	Columbus	2017-08-08 22:13:07.718646	2017-08-08 22:13:07.718646	39.9611755000000031	-82.9987941999999919
16	Fort Worth	2017-08-08 22:13:08.536829	2017-08-08 22:13:08.536829	32.7554883000000032	-97.3307657999999947
17	Charlotte	2017-08-08 22:13:09.293723	2017-08-08 22:13:09.293723	35.2270869000000033	-80.8431266999999991
18	Detroit	2017-08-08 22:13:10.386265	2017-08-08 22:13:10.386265	42.3314269999999979	-83.0457538
19	El Paso	2017-08-08 22:13:11.198353	2017-08-08 22:13:11.198353	31.7618778000000006	-106.485021700000004
20	Memphis	2017-08-08 22:13:11.740551	2017-08-08 22:13:11.740551	35.1495342999999991	-90.0489800999999943
21	Boston	2017-08-08 22:13:12.362514	2017-08-08 22:13:12.362514	42.3600824999999972	-71.0588800999999961
22	Seattle	2017-08-08 22:13:12.913597	2017-08-08 22:13:12.913597	47.6062094999999985	-122.332070799999997
23	Denver	2017-08-08 22:13:13.505318	2017-08-08 22:13:13.505318	39.739235800000003	-104.990251000000001
24	Washington	2017-08-08 22:13:14.537479	2017-08-08 22:13:14.537479	47.7510740999999967	-120.740138599999995
25	Nashville	2017-08-08 22:13:15.621914	2017-08-08 22:13:15.621914	36.1626637999999971	-86.7816016000000019
26	Baltimore	2017-08-08 22:13:16.441821	2017-08-08 22:13:16.441821	39.2903847999999982	-76.6121892999999972
27	Louisville	2017-08-08 22:13:17.052174	2017-08-08 22:13:17.052174	38.2526646999999969	-85.758455699999999
28	Portland	2017-08-08 22:13:17.786157	2017-08-08 22:13:17.786157	45.5230621999999983	-122.676481600000002
29	Oklahoma	2017-08-08 22:13:18.75613	2017-08-08 22:13:18.75613	35.0077519000000024	-97.0928770000000014
30	Milwaukee	2017-08-08 22:13:19.58629	2017-08-08 22:13:19.58629	\N	\N
31	Las Vegas	2017-08-08 22:13:20.146157	2017-08-08 22:13:20.146157	36.1699411999999967	-115.139829599999999
32	Albuquerque	2017-08-08 22:13:20.784584	2017-08-08 22:13:20.784584	35.0853335999999985	-106.605553400000005
33	Tucson	2017-08-08 22:13:21.685815	2017-08-08 22:13:21.685815	32.2217429000000024	-110.926479
34	Fresno	2017-08-08 22:13:22.43164	2017-08-08 22:13:22.43164	36.7468422000000032	-119.772586799999999
35	Sacramento	2017-08-08 22:13:23.26948	2017-08-08 22:13:23.26948	38.5815719000000001	-121.494399599999994
36	Long Beach	2017-08-08 22:13:23.958024	2017-08-08 22:13:23.958024	33.7700504000000024	-118.193739500000007
37	Kansas	2017-08-08 22:13:24.887413	2017-08-08 22:13:24.887413	39.0119019999999992	-98.4842464999999976
38	Mesa	2017-08-08 22:13:25.569314	2017-08-08 22:13:25.569314	33.4151843	-111.831472399999996
39	Virginia Beach	2017-08-08 22:13:26.530036	2017-08-08 22:13:26.530036	36.8529263	-75.9779849999999897
40	Atlanta	2017-08-08 22:13:27.145694	2017-08-08 22:13:27.145694	33.7489953999999983	-84.3879823999999985
41	Colorado Springs	2017-08-08 22:13:28.011586	2017-08-08 22:13:28.011586	38.833881599999998	-104.821363399999996
42	Raleigh	2017-08-08 22:13:29.02515	2017-08-08 22:13:29.02515	35.7795897000000025	-78.6381786999999974
43	Omaha	2017-08-08 22:13:29.64995	2017-08-08 22:13:29.64995	41.2523634000000001	-95.9979882999999887
44	Miami	2017-08-08 22:13:30.32117	2017-08-08 22:13:30.32117	25.7616797999999996	-80.1917901999999998
45	Oakland	2017-08-08 22:13:31.237715	2017-08-08 22:13:31.237715	37.8043637000000032	-122.271113700000001
46	Tulsa	2017-08-08 22:13:31.836267	2017-08-08 22:13:31.836267	36.1539816000000016	-95.9927750000000088
47	Minneapolis	2017-08-08 22:13:32.695809	2017-08-08 22:13:32.695809	44.9777529999999999	-93.2650107999999989
48	Cleveland	2017-08-08 22:13:33.344219	2017-08-08 22:13:33.344219	41.4993199999999973	-81.6943605000000019
49	Wichita	2017-08-08 22:13:34.001978	2017-08-08 22:13:34.001978	37.6871760999999879	-97.3300529999999924
50	Arlington	2017-08-08 22:13:34.845992	2017-08-08 22:13:34.845992	32.7356869999999986	-97.1080655999999891
51	New Orleans	2017-08-08 22:13:35.477154	2017-08-08 22:13:35.477154	29.9510657999999914	-90.0715323000000012
52	Bakersfield	2017-08-08 22:13:36.096311	2017-08-08 22:13:36.096311	35.3732921000000005	-119.018712500000007
53	Tampa	2017-08-08 22:13:36.923363	2017-08-08 22:13:36.923363	27.9505750000000006	-82.4571775999999943
54	Honolulu	2017-08-08 22:13:37.806866	2017-08-08 22:13:37.806866	21.306944399999999	-157.858333299999998
55	Anaheim	2017-08-08 22:13:38.463591	2017-08-08 22:13:38.463591	33.8365932000000029	-117.914301199999997
56	Aurora	2017-08-08 22:13:39.226864	2017-08-08 22:13:39.226864	41.7605848999999978	-88.3200715000000116
57	Santa Ana	2017-08-08 22:13:40.040484	2017-08-08 22:13:40.040484	33.7454724999999982	-117.867653000000004
58	St. Louis	2017-08-08 22:13:40.717325	2017-08-08 22:13:40.717325	38.6270025000000032	-90.1994041999999894
59	Riverside	2017-08-08 22:13:41.367766	2017-08-08 22:13:41.367766	33.9533486999999994	-117.396156399999995
60	Corpus Christi	2017-08-08 22:13:42.237625	2017-08-08 22:13:42.237625	27.8005828000000008	-97.396380999999991
61	Pittsburgh	2017-08-08 22:13:42.898521	2017-08-08 22:13:42.898521	40.4406247999999877	-79.9958864000000034
62	Lexington	2017-08-08 22:13:43.730119	2017-08-08 22:13:43.730119	38.0405836999999991	-84.5037164000000018
63	Anchorage	2017-08-08 22:13:44.293868	2017-08-08 22:13:44.293868	61.2180555999999996	-149.900277799999998
64	Stockton	2017-08-08 22:13:44.901395	2017-08-08 22:13:44.901395	37.9577016	-121.290779599999993
65	Cincinnati	2017-08-08 22:13:45.475486	2017-08-08 22:13:45.475486	39.1031181999999973	-84.5120196000000021
66	St. Paul	2017-08-08 22:13:46.356831	2017-08-08 22:13:46.356831	44.9537029000000032	-93.0899577999999934
67	Toledo	2017-08-08 22:13:46.971649	2017-08-08 22:13:46.971649	41.6639382999999981	-83.5552120000000116
68	Newark	2017-08-08 22:13:47.617431	2017-08-08 22:13:47.617431	40.7356570000000033	-74.1723666999999978
69	Greensboro	2017-08-08 22:13:48.617105	2017-08-08 22:13:48.617105	36.0726354000000029	-79.7919753999999983
70	Plano	2017-08-08 22:13:49.678289	2017-08-08 22:13:49.678289	33.0198431000000028	-96.698885599999997
71	Henderson	2017-08-08 22:13:50.710732	2017-08-08 22:13:50.710732	36.0395247000000012	-114.981721300000004
72	Lincoln	2017-08-08 22:13:51.809076	2017-08-08 22:13:51.809076	40.8257625000000033	-96.6851982000000021
73	Buffalo	2017-08-08 22:13:52.632119	2017-08-08 22:13:52.632119	42.8864467999999874	-78.8783688999999981
74	Fort Wayne	2017-08-08 22:13:53.292169	2017-08-08 22:13:53.292169	41.0792730000000006	-85.1393513000000013
75	Jersey	2017-08-08 22:13:53.668805	2017-08-08 22:13:53.668805	49.2144389999999987	-2.13125000000000009
76	Chula Vista	2017-08-08 22:13:54.282013	2017-08-08 22:13:54.282013	32.6400541000000004	-117.084195500000007
77	Orlando	2017-08-08 22:13:54.717571	2017-08-08 22:13:54.717571	28.5383354999999987	-81.3792365000000046
78	St. Petersburg	2017-08-08 22:13:55.638705	2017-08-08 22:13:55.638705	59.9342802000000034	30.3350985999999985
79	Norfolk	2017-08-08 22:13:56.29034	2017-08-08 22:13:56.29034	36.8507688999999985	-76.2858725999999905
80	Chandler	2017-08-08 22:13:57.043292	2017-08-08 22:13:57.043292	33.3061604999999972	-111.841250200000005
81	Laredo	2017-08-08 22:13:57.814526	2017-08-08 22:13:57.814526	27.530567099999999	-99.48032409999999
82	Madison	2017-08-08 22:13:58.411921	2017-08-08 22:13:58.411921	43.0730517000000006	-89.4012302000000005
83	Durham	2017-08-08 22:13:59.09064	2017-08-08 22:13:59.09064	35.9940329000000006	-78.8986189999999965
84	Lubbock	2017-08-08 22:14:00.019877	2017-08-08 22:14:00.019877	33.5778631000000019	-101.855166499999996
85	Winston-Salem	2017-08-08 22:14:00.70597	2017-08-08 22:14:00.70597	36.0998595999999878	-80.2442159999999944
86	Garland	2017-08-08 22:14:01.535355	2017-08-08 22:14:01.535355	32.912624000000001	-96.6388832999999892
87	Glendale	2017-08-08 22:14:02.634955	2017-08-08 22:14:02.634955	34.1425077999999971	-118.255075000000005
88	Hialeah	2017-08-08 22:14:03.235114	2017-08-08 22:14:03.235114	25.8575963000000009	-80.2781056999999976
89	Reno	2017-08-08 22:14:03.867146	2017-08-08 22:14:03.867146	39.5296329000000028	-119.813802699999997
90	Baton Rouge	2017-08-08 22:14:04.722005	2017-08-08 22:14:04.722005	30.4582829000000004	-91.140319599999998
91	Irvine	2017-08-08 22:14:05.367704	2017-08-08 22:14:05.367704	33.6845672999999977	-117.826504900000003
92	Chesapeake	2017-08-08 22:14:06.138878	2017-08-08 22:14:06.138878	36.7682087999999965	-76.2874927000000014
93	Irving	2017-08-08 22:14:06.77829	2017-08-08 22:14:06.77829	32.8140177000000008	-96.9488944999999944
94	Scottsdale	2017-08-08 22:14:07.425648	2017-08-08 22:14:07.425648	33.4941704000000016	-111.926051900000004
95	North Las Vegas	2017-08-08 22:14:08.061528	2017-08-08 22:14:08.061528	36.1988592000000011	-115.117501300000001
96	Fremont	2017-08-08 22:14:08.876306	2017-08-08 22:14:08.876306	37.5482696999999987	-121.988571899999997
97	Gilbert Town	2017-08-08 22:14:09.573205	2017-08-08 22:14:09.573205	33.3528263999999979	-111.789027000000004
98	San Bernardino	2017-08-08 22:14:10.473981	2017-08-08 22:14:10.473981	34.1083448999999987	-117.289765200000005
99	Boise	2017-08-08 22:14:11.229804	2017-08-08 22:14:11.229804	43.6187102000000024	-116.214606799999999
100	Birmingham	2017-08-08 22:14:11.497993	2017-08-08 22:14:11.497993	33.5206608000000017	-86.8024899999999917
101	Fort Lauderdale	2017-08-08 22:14:12.274701	2017-08-08 22:14:12.274701	26.1224385999999988	-80.1373174000000148
102	Aventura	2017-08-10 14:28:17.495323	2017-08-10 14:28:17.495323	25.9564811999999989	-80.1392120999999946
103	Kuna	2017-08-10 14:36:54.456614	2017-08-10 14:36:54.456614	37.6356171999999987	-122.422815999999997
104	Rialto	2017-08-10 14:39:55.761543	2017-08-10 14:39:55.761543	\N	\N
105	San Bernardino County	2017-08-10 14:43:33.906969	2017-08-10 14:43:33.906969	34.9592083000000002	-116.419388999999995
106	New York	2017-08-10 14:48:14.645225	2017-08-10 14:48:14.645225	40.7127837000000028	-74.0059413000000035
107	Mount Hope	2017-08-10 15:04:18.690833	2017-08-10 15:04:18.690833	\N	\N
108	Salt Lake City	2017-08-10 15:04:47.343366	2017-08-10 15:04:47.343366	40.7607793000000029	-111.891047400000005
\.


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"cities_id_seq"', 108, true);


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "comments" ("id", "created_at", "updated_at", "picture_id", "body", "user_id") FROM stdin;
4	2017-08-08 22:44:09.663968	2017-08-08 22:44:09.663968	10	test	3
\.


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"comments_id_seq"', 4, true);


--
-- Data for Name: pictures; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "pictures" ("id", "title", "created_at", "updated_at", "user_id", "image_file_name", "image_content_type", "image_file_size", "image_updated_at", "cached_votes_total", "cached_votes_score", "cached_votes_up", "cached_votes_down", "cached_weighted_score", "cached_weighted_total", "cached_weighted_average", "latitude", "longitude", "city_id") FROM stdin;
10	Finland	2017-08-08 22:41:49.223102	2017-08-08 22:43:46.908101	1	A-Breathtakingly-Beautiful-Picture-of-a-Winter-Morning-In-Finland.jpg	image/jpeg	148568	2017-08-08 22:41:48.721038	1	1	1	0	1	1	0	25.7631000000000014	-80.1911000000000058	44
11	meadow	2017-08-08 22:43:38.129281	2017-08-08 22:43:51.73912	3	_83351965_explorer273lincolnshirewoldssouthpicturebynicholassilkstone.jpg	image/jpeg	140106	2017-08-08 22:43:37.611998	1	1	1	0	1	1	0	25.7631000000000014	-80.1911000000000058	44
\.


--
-- Name: pictures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"pictures_id_seq"', 11, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "schema_migrations" ("version") FROM stdin;
20170806024335
20170805164202
20170805175608
20170805192520
20170805192640
20170805192917
20170805195447
20170805195507
20170805200319
20170805221323
20170805231659
20170806000252
20170806011942
20170806013550
20170806014022
20170806233650
20170807014429
20170808005414
20170808005506
20170808011101
20170809203111
20170809203123
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "users" ("id", "username", "email", "created_at", "updated_at", "password_digest", "name") FROM stdin;
1	tim9	tim@wyn.co	2017-08-06 18:00:24.085412	2017-08-06 18:00:24.085412	$2a$10$7WlsaOBe8p9652SUGHpahu8B1fEH3oaCmzo1Su90hUV2RqNmqXIGS	Tim
2	mratliff	m@ratliff.co	2017-08-07 20:37:03.791254	2017-08-07 20:37:03.791254	$2a$10$ETgHKqe/rihvWpu42jrfaO1T4a36/S8iiRxSeoztATLOaDd17NmqK	Mark
3	pkbanks	pk@wyncode.co	2017-08-08 21:38:51.163006	2017-08-08 21:38:51.163006	$2a$10$efxlMg.qBnvy.m9Q8/z4X.KB802wpNlDC8U7EGMh49BNL.TSMXrkW	pk
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"users_id_seq"', 3, true);


--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "votes" ("id", "votable_type", "votable_id", "voter_type", "voter_id", "vote_flag", "vote_scope", "vote_weight", "created_at", "updated_at") FROM stdin;
14	Picture	10	User	3	t	\N	1	2017-08-08 22:43:46.887364	2017-08-08 22:43:46.887364
15	Picture	11	User	3	t	\N	1	2017-08-08 22:43:51.719337	2017-08-08 22:43:51.719337
\.


--
-- Name: votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"votes_id_seq"', 15, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "ar_internal_metadata"
    ADD CONSTRAINT "ar_internal_metadata_pkey" PRIMARY KEY ("key");


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "cities"
    ADD CONSTRAINT "cities_pkey" PRIMARY KEY ("id");


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments"
    ADD CONSTRAINT "comments_pkey" PRIMARY KEY ("id");


--
-- Name: pictures pictures_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "pictures"
    ADD CONSTRAINT "pictures_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "votes"
    ADD CONSTRAINT "votes_pkey" PRIMARY KEY ("id");


--
-- Name: index_comments_on_picture_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_comments_on_picture_id" ON "comments" USING "btree" ("picture_id");


--
-- Name: index_comments_on_user_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_comments_on_user_id" ON "comments" USING "btree" ("user_id");


--
-- Name: index_pictures_on_cached_votes_down; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_votes_down" ON "pictures" USING "btree" ("cached_votes_down");


--
-- Name: index_pictures_on_cached_votes_score; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_votes_score" ON "pictures" USING "btree" ("cached_votes_score");


--
-- Name: index_pictures_on_cached_votes_total; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_votes_total" ON "pictures" USING "btree" ("cached_votes_total");


--
-- Name: index_pictures_on_cached_votes_up; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_votes_up" ON "pictures" USING "btree" ("cached_votes_up");


--
-- Name: index_pictures_on_cached_weighted_average; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_weighted_average" ON "pictures" USING "btree" ("cached_weighted_average");


--
-- Name: index_pictures_on_cached_weighted_score; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_weighted_score" ON "pictures" USING "btree" ("cached_weighted_score");


--
-- Name: index_pictures_on_cached_weighted_total; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_cached_weighted_total" ON "pictures" USING "btree" ("cached_weighted_total");


--
-- Name: index_pictures_on_city_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_city_id" ON "pictures" USING "btree" ("city_id");


--
-- Name: index_pictures_on_user_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_user_id" ON "pictures" USING "btree" ("user_id");


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: CC
--

CREATE UNIQUE INDEX "index_users_on_email" ON "users" USING "btree" ("email");


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: CC
--

CREATE UNIQUE INDEX "index_users_on_username" ON "users" USING "btree" ("username");


--
-- Name: index_votes_on_votable_id_and_votable_type_and_vote_scope; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_votable_id_and_votable_type_and_vote_scope" ON "votes" USING "btree" ("votable_id", "votable_type", "vote_scope");


--
-- Name: index_votes_on_votable_type_and_votable_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_votable_type_and_votable_id" ON "votes" USING "btree" ("votable_type", "votable_id");


--
-- Name: index_votes_on_voter_id_and_voter_type_and_vote_scope; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_voter_id_and_voter_type_and_vote_scope" ON "votes" USING "btree" ("voter_id", "voter_type", "vote_scope");


--
-- Name: index_votes_on_voter_type_and_voter_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_voter_type_and_voter_id" ON "votes" USING "btree" ("voter_type", "voter_id");


--
-- Name: comments fk_rails_03de2dc08c; Type: FK CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments"
    ADD CONSTRAINT "fk_rails_03de2dc08c" FOREIGN KEY ("user_id") REFERENCES "users"("id");


--
-- Name: pictures fk_rails_a17aff4e83; Type: FK CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "pictures"
    ADD CONSTRAINT "fk_rails_a17aff4e83" FOREIGN KEY ("city_id") REFERENCES "cities"("id");


--
-- Name: comments fk_rails_b86f865b7e; Type: FK CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments"
    ADD CONSTRAINT "fk_rails_b86f865b7e" FOREIGN KEY ("picture_id") REFERENCES "pictures"("id");


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect -reuse-previous=on "dbname='photogur-test'"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "ar_internal_metadata" (
    "key" character varying NOT NULL,
    "value" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "ar_internal_metadata" OWNER TO "CC";

--
-- Name: comments; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "comments" (
    "id" bigint NOT NULL,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "picture_id" bigint,
    "body" "text",
    "user_id" bigint
);


ALTER TABLE "comments" OWNER TO "CC";

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "comments_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "comments_id_seq" OWNER TO "CC";

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "comments_id_seq" OWNED BY "comments"."id";


--
-- Name: pictures; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "pictures" (
    "id" bigint NOT NULL,
    "title" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "user_id" integer,
    "image_file_name" character varying,
    "image_content_type" character varying,
    "image_file_size" integer,
    "image_updated_at" timestamp without time zone
);


ALTER TABLE "pictures" OWNER TO "CC";

--
-- Name: pictures_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "pictures_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "pictures_id_seq" OWNER TO "CC";

--
-- Name: pictures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "pictures_id_seq" OWNED BY "pictures"."id";


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "schema_migrations" (
    "version" character varying NOT NULL
);


ALTER TABLE "schema_migrations" OWNER TO "CC";

--
-- Name: users; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "users" (
    "id" bigint NOT NULL,
    "username" character varying,
    "email" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "password_digest" character varying,
    "name" character varying
);


ALTER TABLE "users" OWNER TO "CC";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "users_id_seq" OWNER TO "CC";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "users_id_seq" OWNED BY "users"."id";


--
-- Name: votes; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "votes" (
    "id" bigint NOT NULL,
    "votable_type" character varying,
    "votable_id" integer,
    "voter_type" character varying,
    "voter_id" integer,
    "vote_flag" boolean,
    "vote_scope" character varying,
    "vote_weight" integer,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "votes" OWNER TO "CC";

--
-- Name: votes_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "votes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "votes_id_seq" OWNER TO "CC";

--
-- Name: votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "votes_id_seq" OWNED BY "votes"."id";


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments" ALTER COLUMN "id" SET DEFAULT "nextval"('"comments_id_seq"'::"regclass");


--
-- Name: pictures id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "pictures" ALTER COLUMN "id" SET DEFAULT "nextval"('"pictures_id_seq"'::"regclass");


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "users" ALTER COLUMN "id" SET DEFAULT "nextval"('"users_id_seq"'::"regclass");


--
-- Name: votes id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "votes" ALTER COLUMN "id" SET DEFAULT "nextval"('"votes_id_seq"'::"regclass");


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "ar_internal_metadata" ("key", "value", "created_at", "updated_at") FROM stdin;
environment	development	2017-08-06 17:58:30.987975	2017-08-06 17:58:30.987975
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "comments" ("id", "created_at", "updated_at", "picture_id", "body", "user_id") FROM stdin;
\.


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"comments_id_seq"', 1, false);


--
-- Data for Name: pictures; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "pictures" ("id", "title", "created_at", "updated_at", "user_id", "image_file_name", "image_content_type", "image_file_size", "image_updated_at") FROM stdin;
\.


--
-- Name: pictures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"pictures_id_seq"', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "schema_migrations" ("version") FROM stdin;
20170806024335
20170805164202
20170805175608
20170805192520
20170805192640
20170805192917
20170805195447
20170805195507
20170805200319
20170805221323
20170805231659
20170806000252
20170806011942
20170806013550
20170806014022
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "users" ("id", "username", "email", "created_at", "updated_at", "password_digest", "name") FROM stdin;
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"users_id_seq"', 1, false);


--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "votes" ("id", "votable_type", "votable_id", "voter_type", "voter_id", "vote_flag", "vote_scope", "vote_weight", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"votes_id_seq"', 1, false);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "ar_internal_metadata"
    ADD CONSTRAINT "ar_internal_metadata_pkey" PRIMARY KEY ("key");


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments"
    ADD CONSTRAINT "comments_pkey" PRIMARY KEY ("id");


--
-- Name: pictures pictures_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "pictures"
    ADD CONSTRAINT "pictures_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "votes"
    ADD CONSTRAINT "votes_pkey" PRIMARY KEY ("id");


--
-- Name: index_comments_on_picture_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_comments_on_picture_id" ON "comments" USING "btree" ("picture_id");


--
-- Name: index_comments_on_user_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_comments_on_user_id" ON "comments" USING "btree" ("user_id");


--
-- Name: index_pictures_on_user_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_pictures_on_user_id" ON "pictures" USING "btree" ("user_id");


--
-- Name: index_votes_on_votable_id_and_votable_type_and_vote_scope; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_votable_id_and_votable_type_and_vote_scope" ON "votes" USING "btree" ("votable_id", "votable_type", "vote_scope");


--
-- Name: index_votes_on_votable_type_and_votable_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_votable_type_and_votable_id" ON "votes" USING "btree" ("votable_type", "votable_id");


--
-- Name: index_votes_on_voter_id_and_voter_type_and_vote_scope; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_voter_id_and_voter_type_and_vote_scope" ON "votes" USING "btree" ("voter_id", "voter_type", "vote_scope");


--
-- Name: index_votes_on_voter_type_and_voter_id; Type: INDEX; Schema: public; Owner: CC
--

CREATE INDEX "index_votes_on_voter_type_and_voter_id" ON "votes" USING "btree" ("voter_type", "voter_id");


--
-- Name: comments fk_rails_03de2dc08c; Type: FK CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments"
    ADD CONSTRAINT "fk_rails_03de2dc08c" FOREIGN KEY ("user_id") REFERENCES "users"("id");


--
-- Name: comments fk_rails_b86f865b7e; Type: FK CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "comments"
    ADD CONSTRAINT "fk_rails_b86f865b7e" FOREIGN KEY ("picture_id") REFERENCES "pictures"("id");


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect "postgres"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "postgres" IS 'default administrative connection database';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect "template1"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "template1" IS 'default template for new databases';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect -reuse-previous=on "dbname='wyncode-todo-dev'"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "ar_internal_metadata" (
    "key" character varying NOT NULL,
    "value" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "ar_internal_metadata" OWNER TO "CC";

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "schema_migrations" (
    "version" character varying NOT NULL
);


ALTER TABLE "schema_migrations" OWNER TO "CC";

--
-- Name: todo_items; Type: TABLE; Schema: public; Owner: CC
--

CREATE TABLE "todo_items" (
    "id" bigint NOT NULL,
    "description" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "todo_items" OWNER TO "CC";

--
-- Name: todo_items_id_seq; Type: SEQUENCE; Schema: public; Owner: CC
--

CREATE SEQUENCE "todo_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "todo_items_id_seq" OWNER TO "CC";

--
-- Name: todo_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: CC
--

ALTER SEQUENCE "todo_items_id_seq" OWNED BY "todo_items"."id";


--
-- Name: todo_items id; Type: DEFAULT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "todo_items" ALTER COLUMN "id" SET DEFAULT "nextval"('"todo_items_id_seq"'::"regclass");


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "ar_internal_metadata" ("key", "value", "created_at", "updated_at") FROM stdin;
environment	development	2017-08-03 17:49:51.67702	2017-08-03 17:49:51.67702
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "schema_migrations" ("version") FROM stdin;
20170803135812
\.


--
-- Data for Name: todo_items; Type: TABLE DATA; Schema: public; Owner: CC
--

COPY "todo_items" ("id", "description", "created_at", "updated_at") FROM stdin;
2	homework	2017-08-12 16:55:11.439549	2017-08-12 16:55:11.439549
3	finish cleaning up projects	2017-08-12 16:55:34.205331	2017-08-12 16:55:34.205331
\.


--
-- Name: todo_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: CC
--

SELECT pg_catalog.setval('"todo_items_id_seq"', 3, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "ar_internal_metadata"
    ADD CONSTRAINT "ar_internal_metadata_pkey" PRIMARY KEY ("key");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: todo_items todo_items_pkey; Type: CONSTRAINT; Schema: public; Owner: CC
--

ALTER TABLE ONLY "todo_items"
    ADD CONSTRAINT "todo_items_pkey" PRIMARY KEY ("id");


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\connect -reuse-previous=on "dbname='wyncode-todo-test'"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA "public" FROM PUBLIC;
REVOKE ALL ON SCHEMA "public" FROM "postgres";
GRANT ALL ON SCHEMA "public" TO "postgres";
GRANT ALL ON SCHEMA "public" TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

